package co.edu.unbosque.NominaEmpleadosAPI.repository;

import co.edu.unbosque.NominaEmpleadosAPI.entity.Incapacidad;
import org.springframework.stereotype.Repository;

@Repository
public interface IIncapacidadRepository extends BasicRepositoy<Incapacidad, Integer> {
}
