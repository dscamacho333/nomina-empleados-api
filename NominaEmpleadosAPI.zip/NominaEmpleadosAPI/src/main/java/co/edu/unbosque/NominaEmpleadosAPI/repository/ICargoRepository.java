package co.edu.unbosque.NominaEmpleadosAPI.repository;

import co.edu.unbosque.NominaEmpleadosAPI.entity.Cargo;
import org.springframework.stereotype.Repository;

@Repository
public interface ICargoRepository extends BasicRepositoy<Cargo,Integer> {
}
