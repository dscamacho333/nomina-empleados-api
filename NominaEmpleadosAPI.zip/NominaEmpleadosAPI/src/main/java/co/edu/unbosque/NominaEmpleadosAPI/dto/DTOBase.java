package co.edu.unbosque.NominaEmpleadosAPI.dto;

import lombok.*;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class DTOBase {

    private boolean isDeleted;


}
