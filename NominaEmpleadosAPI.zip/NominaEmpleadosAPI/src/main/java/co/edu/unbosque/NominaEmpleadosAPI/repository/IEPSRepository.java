package co.edu.unbosque.NominaEmpleadosAPI.repository;

import co.edu.unbosque.NominaEmpleadosAPI.entity.EPS;
import org.springframework.stereotype.Repository;

@Repository
public interface IEPSRepository extends BasicRepositoy<EPS,Integer> {
}
