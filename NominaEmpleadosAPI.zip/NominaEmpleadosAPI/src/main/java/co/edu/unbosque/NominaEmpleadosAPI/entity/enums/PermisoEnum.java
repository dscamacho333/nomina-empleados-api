package co.edu.unbosque.NominaEmpleadosAPI.entity.enums;

public enum PermisoEnum {

    CREAR,
    LEER,
    ACTUALIZAR,
    ELIMINAR,
    LEER_TODO


}
