package co.edu.unbosque.NominaEmpleadosAPI.entity.enums;

public enum RolEnum {

    ADMIN,
    USUARIO,
    INVITADO,
    DESARROLLADOR

}
