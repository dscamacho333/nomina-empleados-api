package co.edu.unbosque.NominaEmpleadosAPI.repository;

import co.edu.unbosque.NominaEmpleadosAPI.entity.Pension;
import org.springframework.stereotype.Repository;

@Repository
public interface IPensionRepository extends BasicRepositoy<Pension,Integer> {
}
