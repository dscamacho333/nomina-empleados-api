package co.edu.unbosque.NominaEmpleadosAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NominaEmpleadosApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
