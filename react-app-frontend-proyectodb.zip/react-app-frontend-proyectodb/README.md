# React + Vite

This template provides a minimal setup to get React working in Vite with HMR and some ESLint rules.

Currently, two official plugins are available:

- [@vitejs/plugin-react](https://github.com/vitejs/vite-plugin-react/blob/main/packages/plugin-react/README.md) uses [Babel](https://babeljs.io/) for Fast Refresh
- [@vitejs/plugin-react-swc](https://github.com/vitejs/vite-plugin-react-swc) uses [SWC](https://swc.rs/) for Fast Refresh

npm i
npm i @emotion/react @emotion/styled @mui/material axios bootstrap chart.js chartjs-plugin-datalabels dotenv react-bootstrap react-chartjs-2 react-dom react-google-recaptcha react-router-dom @react-pdf/renderer html2canvas@1.0.0-alpha.12
